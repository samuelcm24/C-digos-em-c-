/*
UFMT - UNIVERSIDADE DO VALE DO ARAGUAIA
DISCENTE: Samuel Campos Martins
DOCENTE: Thiago

MATERIA: Estruturas De Dados 1
*/


#include <stdio.h>
#include <stdlib.h>

typedef struct No
{
    char valor;
    struct No* proximo;
} No;

typedef struct Fila
{
    No* inicio;
    No* fim;
    int tamanho;
} Fila;

Fila* criar_fila(){
    Fila* f = (Fila*) malloc(sizeof(Fila));
    if (f == NULL){
        printf("Erro ao alocar memoria para a fila!!\n");
        exit(1);
    }
    f->inicio = NULL;
    f->fim = NULL;
    f->tamanho = 0;
    return f;
}

void imprimir_fila(Fila* f){
    printf("Fila: [");
    No* atual = f->inicio;
    while(atual != NULL){
        printf("%c", atual->valor);
        if (atual->proximo != NULL){
            printf(", ");
        }
        atual = atual->proximo;
    }
    printf("] | Tamanho: %d\n", f->tamanho);
}

void enqueue(Fila* f, char valor){
    No* novo_no = (No*) malloc(sizeof(No));
    if (novo_no == NULL){
        printf("Erro ao alocar memoria para o novo nó!!!\n");
        return;
    }
    novo_no->valor = valor;
    novo_no->proximo = NULL;

    if(f->fim == NULL){
        f->inicio = novo_no;
        f->fim = novo_no;
    } else{
        f->fim->proximo = novo_no;
        f->fim = novo_no;
    }

    f->tamanho++;
}

char dequeue(Fila* f){
    if (f->inicio == NULL){
        printf("A fila esta vazia. Não é possiível remover. \n");
        return '\0';
    }

    No* no_removido = f->inicio;
    char valor_retornado = no_removido->valor;

    f->inicio = f->inicio->proximo;


    if (f->inicio == NULL){
        f->fim = NULL;
    }

    free(no_removido);

    f->tamanho--;

    return valor_retornado;
}

int size(Fila* f){
    return f->tamanho;
}

void liberar_memoria(Fila* f){
    while (f->inicio != NULL)
    {
        dequeue(f);
    }
    free(f);
}

int main(){

    Fila* minha_fila = criar_fila();

    printf("\n -------- Inciando Fila --------\n");
    imprimir_fila(minha_fila);

    printf("\nAdicionando 'A', 'B', 'C'...\n");
    enqueue(minha_fila, 'A');
    enqueue(minha_fila, 'B');
    enqueue(minha_fila, 'C');
    imprimir_fila(minha_fila);

    printf("\nRemovendo um elemento...\n");
    char removido = dequeue(minha_fila);
    printf("Elemento removido do inicio: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'D' e 'E'.");
    enqueue(minha_fila, 'D');
    enqueue(minha_fila, 'E');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'F' e 'G'.");
    enqueue(minha_fila, 'F');
    enqueue(minha_fila, 'G');
    
    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'H' e 'I'.");
    enqueue(minha_fila, 'H');
    enqueue(minha_fila, 'I');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'J' e 'K'.");
    enqueue(minha_fila, 'J');
    enqueue(minha_fila, 'K');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'L'.");
    enqueue(minha_fila, 'L');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'M' e 'N'.");
    enqueue(minha_fila, 'M');
    enqueue(minha_fila, 'N');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    printf("\n Adicionando 'O'.");
    enqueue(minha_fila, 'O');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);


    printf("\n Adicionando 'P'.");
    enqueue(minha_fila, 'P');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);    


    printf("\n Adicionando 'Q'.");
    enqueue(minha_fila, 'Q');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);


    printf("\n Adicionando 'R'.");
    enqueue(minha_fila, 'R');

    removido = dequeue(minha_fila);
    printf("\n Elemento removido: %c\n", removido);
    imprimir_fila(minha_fila);

    liberar_memoria(minha_fila);
    printf("\nMemoria da fila liberada com sucesso.\n");

    return 0;

}